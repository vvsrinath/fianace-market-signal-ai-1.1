import os
import logging
import yfinance as yf
import pandas as pd
import numpy as np
from flask import Flask, jsonify, request, render_template_string
from flask_cors import CORS
from openai import OpenAI
from datetime import datetime, timedelta
# import talib  # Using custom implementations instead due to compilation issues

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")
CORS(app)

# Initialize OpenAI client
# the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
# do not change this unless explicitly requested by the user
openai_client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

# Major US stocks list
MAJOR_US_STOCKS = {
    # Tech Giants (FAANG+)
    'AAPL': 'Apple Inc.',
    'MSFT': 'Microsoft Corporation',
    'GOOGL': 'Alphabet Inc. Class A',
    'GOOG': 'Alphabet Inc. Class C',
    'AMZN': 'Amazon.com Inc.',
    'META': 'Meta Platforms Inc.',
    'TSLA': 'Tesla Inc.',
    'NVDA': 'NVIDIA Corporation',
    'NFLX': 'Netflix Inc.',
    
    # Major Tech & Growth
    'CRM': 'Salesforce Inc.',
    'ORCL': 'Oracle Corporation',
    'ADBE': 'Adobe Inc.',
    'PYPL': 'PayPal Holdings Inc.',
    'SQ': 'Block Inc.',
    'SHOP': 'Shopify Inc.',
    'UBER': 'Uber Technologies Inc.',
    'LYFT': 'Lyft Inc.',
    'ZOOM': 'Zoom Video Communications Inc.',
    'DOCU': 'DocuSign Inc.',
    
    # Financial Services
    'JPM': 'JPMorgan Chase & Co.',
    'BAC': 'Bank of America Corporation',
    'WFC': 'Wells Fargo & Company',
    'GS': 'The Goldman Sachs Group Inc.',
    'MS': 'Morgan Stanley',
    'C': 'Citigroup Inc.',
    'V': 'Visa Inc.',
    'MA': 'Mastercard Incorporated',
    'AXP': 'American Express Company',
    'BRK.B': 'Berkshire Hathaway Inc. Class B',
    
    # Healthcare & Pharmaceuticals
    'JNJ': 'Johnson & Johnson',
    'UNH': 'UnitedHealth Group Incorporated',
    'PFE': 'Pfizer Inc.',
    'ABBV': 'AbbVie Inc.',
    'TMO': 'Thermo Fisher Scientific Inc.',
    'ABT': 'Abbott Laboratories',
    'DHR': 'Danaher Corporation',
    'BMY': 'Bristol-Myers Squibb Company',
    'AMGN': 'Amgen Inc.',
    'GILD': 'Gilead Sciences Inc.',
    
    # Consumer & Retail
    'HD': 'The Home Depot Inc.',
    'WMT': 'Walmart Inc.',
    'COST': 'Costco Wholesale Corporation',
    'TGT': 'Target Corporation',
    'LOW': 'Lowe\'s Companies Inc.',
    'SBUX': 'Starbucks Corporation',
    'MCD': 'McDonald\'s Corporation',
    'KO': 'The Coca-Cola Company',
    'PEP': 'PepsiCo Inc.',
    'NKE': 'NIKE Inc.',
    
    # Industrial & Energy
    'BA': 'The Boeing Company',
    'CAT': 'Caterpillar Inc.',
    'GE': 'General Electric Company',
    'MMM': '3M Company',
    'HON': 'Honeywell International Inc.',
    'LMT': 'Lockheed Martin Corporation',
    'RTX': 'Raytheon Technologies Corporation',
    'XOM': 'Exxon Mobil Corporation',
    'CVX': 'Chevron Corporation',
    'COP': 'ConocoPhillips',
    
    # Telecommunications & Media
    'T': 'AT&T Inc.',
    'VZ': 'Verizon Communications Inc.',
    'CMCSA': 'Comcast Corporation',
    'DIS': 'The Walt Disney Company',
    'TMUS': 'T-Mobile US Inc.',
    
    # ETFs
    'SPY': 'SPDR S&P 500 ETF Trust',
    'QQQ': 'Invesco QQQ Trust',
    'IWM': 'iShares Russell 2000 ETF',
    'VTI': 'Vanguard Total Stock Market ETF',
    'VOO': 'Vanguard S&P 500 ETF'
}

def calculate_rsi(prices, window=14):
    """Calculate Relative Strength Index (RSI)"""
    delta = prices.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

def calculate_macd(prices, fast=12, slow=26, signal=9):
    """Calculate MACD (Moving Average Convergence Divergence)"""
    exp1 = prices.ewm(span=fast, adjust=False).mean()
    exp2 = prices.ewm(span=slow, adjust=False).mean()
    macd = exp1 - exp2
    signal_line = macd.ewm(span=signal, adjust=False).mean()
    histogram = macd - signal_line
    return macd, signal_line, histogram

def calculate_bollinger_bands(prices, window=20, num_std=2):
    """Calculate Bollinger Bands"""
    rolling_mean = prices.rolling(window=window).mean()
    rolling_std = prices.rolling(window=window).std()
    upper_band = rolling_mean + (rolling_std * num_std)
    lower_band = rolling_mean - (rolling_std * num_std)
    return upper_band, rolling_mean, lower_band

def calculate_support_resistance(data, window=20):
    """Calculate support and resistance levels using pivot points"""
    highs = data['High'].rolling(window=window, center=True).max()
    lows = data['Low'].rolling(window=window, center=True).min()
    
    # Find pivot highs and lows
    pivot_highs = data['High'][(data['High'] == highs) & (data['High'].shift(1) != highs) & (data['High'].shift(-1) != highs)]
    pivot_lows = data['Low'][(data['Low'] == lows) & (data['Low'].shift(1) != lows) & (data['Low'].shift(-1) != lows)]
    
    # Get most recent levels
    recent_resistance = pivot_highs.dropna().tail(3).tolist()
    recent_support = pivot_lows.dropna().tail(3).tolist()
    
    # Calculate daily pivot points
    latest = data.iloc[-1]
    pivot = (latest['High'] + latest['Low'] + latest['Close']) / 3
    r1 = 2 * pivot - latest['Low']
    r2 = pivot + (latest['High'] - latest['Low'])
    s1 = 2 * pivot - latest['High']
    s2 = pivot - (latest['High'] - latest['Low'])
    
    return {
        'pivot': round(float(pivot), 2),
        'resistance_levels': [round(float(r), 2) for r in recent_resistance],
        'support_levels': [round(float(s), 2) for s in recent_support],
        'daily_r1': round(float(r1), 2),
        'daily_r2': round(float(r2), 2),
        'daily_s1': round(float(s1), 2),
        'daily_s2': round(float(s2), 2)
    }

def calculate_stop_loss_take_profit(data, signal_type, atr_multiplier=2):
    """Calculate stop loss and take profit levels using ATR"""
    # Calculate Average True Range (ATR)
    high_low = data['High'] - data['Low']
    high_close = np.abs(data['High'] - data['Close'].shift())
    low_close = np.abs(data['Low'] - data['Close'].shift())
    
    ranges = pd.concat([high_low, high_close, low_close], axis=1)
    true_range = ranges.max(axis=1)
    atr = true_range.rolling(window=14).mean()
    
    current_price = float(data['Close'].iloc[-1])
    current_atr = float(atr.iloc[-1])
    
    if signal_type == "BUY":
        stop_loss = current_price - (current_atr * atr_multiplier)
        take_profit = current_price + (current_atr * atr_multiplier * 1.5)  # 1.5:1 reward:risk
    elif signal_type == "SELL":
        stop_loss = current_price + (current_atr * atr_multiplier)
        take_profit = current_price - (current_atr * atr_multiplier * 1.5)
    else:  # HOLD
        stop_loss = current_price - (current_atr * atr_multiplier)
        take_profit = current_price + (current_atr * atr_multiplier)
    
    return {
        'entry_price': round(current_price, 2),
        'stop_loss': round(stop_loss, 2),
        'take_profit': round(take_profit, 2),
        'atr': round(current_atr, 2),
        'risk_reward_ratio': 1.5 if signal_type != "HOLD" else 1.0
    }

def fetch_stock_data(symbol, timeframe="1d"):
    """Fetch stock data using yfinance for different timeframes"""
    try:
        ticker = yf.Ticker(symbol)
        
        # Define periods based on timeframe
        timeframe_config = {
            "1m": {"period": "1d", "interval": "1m"},      # 1 day of 1-minute data
            "5m": {"period": "5d", "interval": "5m"},      # 5 days of 5-minute data
            "15m": {"period": "1mo", "interval": "15m"},   # 1 month of 15-minute data
            "1h": {"period": "3mo", "interval": "1h"},     # 3 months of hourly data
            "4h": {"period": "6mo", "interval": "1h"},     # 6 months of hourly data (we'll resample)
            "1d": {"period": "1y", "interval": "1d"},      # 1 year of daily data
            "1wk": {"period": "2y", "interval": "1wk"},    # 2 years of weekly data
            "1mo": {"period": "5y", "interval": "1mo"}     # 5 years of monthly data
        }
        
        config = timeframe_config.get(timeframe, timeframe_config["1d"])
        data = ticker.history(period=config["period"], interval=config["interval"])
        
        # For 4h timeframe, resample hourly data
        if timeframe == "4h" and not data.empty:
            data = data.resample('4H').agg({
                'Open': 'first',
                'High': 'max',
                'Low': 'min',
                'Close': 'last',
                'Volume': 'sum'
            }).dropna()
        
        if data.empty:
            raise ValueError(f"No data found for symbol {symbol} with timeframe {timeframe}")
            
        return data
    except Exception as e:
        logger.error(f"Error fetching data for {symbol} ({timeframe}): {str(e)}")
        raise

def smart_money_concepts_strategy(data, timeframe="1d"):
    """
    Enhanced Smart Money Concepts (SMC) strategy with additional indicators
    Detect Break of Structure (BOS) and Change of Character (CHoCH)
    """
    try:
        df = data.copy()
        
        # Calculate higher highs and lower lows
        df['HH'] = df['High'].rolling(window=20).max()
        df['LL'] = df['Low'].rolling(window=20).min()
        
        # Detect Break of Structure (BOS)
        df['BOS_Bull'] = (df['Close'] > df['HH'].shift(1)) & (df['Close'].shift(1) <= df['HH'].shift(2))
        df['BOS_Bear'] = (df['Close'] < df['LL'].shift(1)) & (df['Close'].shift(1) >= df['LL'].shift(2))
        
        # Detect Change of Character (CHoCH) - reversal patterns
        df['CHoCH_Bull'] = (df['Close'] > df['High'].shift(1)) & (df['Close'].shift(1) < df['Low'].shift(2))
        df['CHoCH_Bear'] = (df['Close'] < df['Low'].shift(1)) & (df['Close'].shift(1) > df['High'].shift(2))
        
        # Add RSI for confirmation
        df['RSI'] = calculate_rsi(df['Close'])
        
        # Add MACD for momentum confirmation
        df['MACD'], df['MACD_Signal'], df['MACD_Hist'] = calculate_macd(df['Close'])
        
        # Add Bollinger Bands
        df['BB_Upper'], df['BB_Middle'], df['BB_Lower'] = calculate_bollinger_bands(df['Close'])
        
        # Get latest data
        latest_data = df.iloc[-1]
        
        signal = "HOLD"
        confidence = 0.5
        
        bos_bull = latest_data['BOS_Bull'].item() if pd.notna(latest_data['BOS_Bull']) else False
        bos_bear = latest_data['BOS_Bear'].item() if pd.notna(latest_data['BOS_Bear']) else False
        choch_bull = latest_data['CHoCH_Bull'].item() if pd.notna(latest_data['CHoCH_Bull']) else False
        choch_bear = latest_data['CHoCH_Bear'].item() if pd.notna(latest_data['CHoCH_Bear']) else False
        
        # Get additional indicator values
        rsi_value = float(latest_data['RSI']) if pd.notna(latest_data['RSI']) else 50
        macd_value = float(latest_data['MACD']) if pd.notna(latest_data['MACD']) else 0
        macd_signal_value = float(latest_data['MACD_Signal']) if pd.notna(latest_data['MACD_Signal']) else 0
        
        # Enhanced signal logic with confirmations
        if bos_bull or choch_bull:
            signal = "BUY"
            base_confidence = 0.8 if bos_bull else 0.7
            
            # RSI confirmation (not overbought)
            if rsi_value < 70:
                base_confidence += 0.1
            
            # MACD confirmation (bullish momentum)
            if macd_value > macd_signal_value:
                base_confidence += 0.1
                
            confidence = min(base_confidence, 0.95)
            
        elif bos_bear or choch_bear:
            signal = "SELL"
            base_confidence = 0.8 if bos_bear else 0.7
            
            # RSI confirmation (not oversold)
            if rsi_value > 30:
                base_confidence += 0.1
            
            # MACD confirmation (bearish momentum)
            if macd_value < macd_signal_value:
                base_confidence += 0.1
                
            confidence = min(base_confidence, 0.95)
        
        # Calculate support/resistance and stop loss/take profit
        support_resistance = calculate_support_resistance(df)
        risk_management = calculate_stop_loss_take_profit(df, signal)
        
        return {
            "strategy": "Smart Money Concepts",
            "signal": signal,
            "confidence": confidence,
            "details": {
                "bos_bull": bos_bull,
                "bos_bear": bos_bear,
                "choch_bull": choch_bull,
                "choch_bear": choch_bear,
                "rsi": round(rsi_value, 2),
                "macd": round(macd_value, 4),
                "macd_signal": round(macd_signal_value, 4),
                "bb_position": "Above" if latest_data['Close'] > latest_data['BB_Upper'] else "Below" if latest_data['Close'] < latest_data['BB_Lower'] else "Middle"
            },
            "support_resistance": support_resistance,
            "risk_management": risk_management
        }
    except Exception as e:
        logger.error(f"Error in SMC strategy: {str(e)}")
        return {
            "strategy": "Smart Money Concepts",
            "signal": "HOLD",
            "confidence": 0.0,
            "error": str(e)
        }

def sma_crossover_strategy(data, timeframe="1d"):
    """
    Enhanced SMA 20/50 crossover quantitative strategy with additional indicators
    """
    try:
        df = data.copy()
        
        # Calculate SMAs
        df['SMA_20'] = df['Close'].rolling(window=20).mean()
        df['SMA_50'] = df['Close'].rolling(window=50).mean()
        df['SMA_200'] = df['Close'].rolling(window=200).mean()  # Long-term trend
        
        # Add RSI for momentum confirmation
        df['RSI'] = calculate_rsi(df['Close'])
        
        # Add MACD
        df['MACD'], df['MACD_Signal'], df['MACD_Hist'] = calculate_macd(df['Close'])
        
        # Add Volume analysis (if available)
        df['Volume_SMA'] = df['Volume'].rolling(window=20).mean() if 'Volume' in df.columns else None
        
        # Generate signals
        df['Signal'] = 0
        df.loc[df['SMA_20'] > df['SMA_50'], 'Signal'] = 1  # Buy signal
        df.loc[df['SMA_20'] < df['SMA_50'], 'Signal'] = -1  # Sell signal
        
        # Detect crossovers
        df['Position'] = df['Signal'].diff()
        
        # Get latest data
        latest_data = df.iloc[-1]
        
        signal = "HOLD"
        confidence = 0.5
        
        # Get indicator values
        rsi_value = float(latest_data['RSI']) if pd.notna(latest_data['RSI']) else 50
        macd_value = float(latest_data['MACD']) if pd.notna(latest_data['MACD']) else 0
        macd_signal_value = float(latest_data['MACD_Signal']) if pd.notna(latest_data['MACD_Signal']) else 0
        sma_200 = float(latest_data['SMA_200']) if pd.notna(latest_data['SMA_200']) else 0
        current_price = float(latest_data['Close'])
        
        # Enhanced signal logic
        if latest_data['Position'] == 2:  # Bullish crossover (from -1 to 1)
            signal = "BUY"
            base_confidence = 0.75
            
            # Long-term trend confirmation
            if sma_200 > 0 and current_price > sma_200:
                base_confidence += 0.1
            
            # RSI confirmation (not overbought)
            if rsi_value < 70:
                base_confidence += 0.05
            
            # MACD confirmation
            if macd_value > macd_signal_value:
                base_confidence += 0.05
                
            confidence = min(base_confidence, 0.95)
            
        elif latest_data['Position'] == -2:  # Bearish crossover (from 1 to -1)
            signal = "SELL"
            base_confidence = 0.75
            
            # Long-term trend confirmation
            if sma_200 > 0 and current_price < sma_200:
                base_confidence += 0.1
            
            # RSI confirmation (not oversold)
            if rsi_value > 30:
                base_confidence += 0.05
            
            # MACD confirmation
            if macd_value < macd_signal_value:
                base_confidence += 0.05
                
            confidence = min(base_confidence, 0.95)
            
        elif latest_data['Signal'] == 1:  # Currently bullish
            signal = "BUY"
            base_confidence = 0.6
            
            # Additional confirmations for ongoing signal
            if sma_200 > 0 and current_price > sma_200:
                base_confidence += 0.05
            if 30 < rsi_value < 70:
                base_confidence += 0.05
                
            confidence = min(base_confidence, 0.8)
            
        elif latest_data['Signal'] == -1:  # Currently bearish
            signal = "SELL"
            base_confidence = 0.6
            
            # Additional confirmations for ongoing signal
            if sma_200 > 0 and current_price < sma_200:
                base_confidence += 0.05
            if 30 < rsi_value < 70:
                base_confidence += 0.05
                
            confidence = min(base_confidence, 0.8)
        
        # Calculate support/resistance and risk management
        support_resistance = calculate_support_resistance(df)
        risk_management = calculate_stop_loss_take_profit(df, signal)
        
        # Volume analysis
        volume_analysis = "Normal"
        if 'Volume' in df.columns and df['Volume_SMA'].notna().any():
            current_volume = float(latest_data['Volume'])
            avg_volume = float(latest_data['Volume_SMA']) if pd.notna(latest_data['Volume_SMA']) else current_volume
            if current_volume > avg_volume * 1.5:
                volume_analysis = "High"
            elif current_volume < avg_volume * 0.5:
                volume_analysis = "Low"
        
        return {
            "strategy": "SMA Crossover",
            "signal": signal,
            "confidence": confidence,
            "details": {
                "sma_20": round(float(latest_data['SMA_20']), 2) if pd.notna(latest_data['SMA_20']) else 0.0,
                "sma_50": round(float(latest_data['SMA_50']), 2) if pd.notna(latest_data['SMA_50']) else 0.0,
                "sma_200": round(sma_200, 2) if sma_200 > 0 else None,
                "current_price": round(current_price, 2),
                "crossover": (latest_data['Position'] != 0).item() if pd.notna(latest_data['Position']) else False,
                "rsi": round(rsi_value, 2),
                "macd": round(macd_value, 4),
                "macd_signal": round(macd_signal_value, 4),
                "volume_analysis": volume_analysis,
                "trend": "Bullish" if current_price > sma_200 and sma_200 > 0 else "Bearish" if sma_200 > 0 else "Neutral"
            },
            "support_resistance": support_resistance,
            "risk_management": risk_management
        }
    except Exception as e:
        logger.error(f"Error in SMA strategy: {str(e)}")
        return {
            "strategy": "SMA Crossover",
            "signal": "HOLD",
            "confidence": 0.0,
            "error": str(e)
        }

@app.route('/')
def index():
    """Serve the main page"""
    with open('index.html', 'r') as f:
        return f.read()

@app.route('/api/instruments')
def get_financial_instruments():
    """API endpoint to get comprehensive list of financial instruments"""
    try:
        instruments = {
            "US Stocks": {
                "Tech Giants": [
                    {"symbol": "AAPL", "name": "Apple Inc."},
                    {"symbol": "MSFT", "name": "Microsoft Corporation"},
                    {"symbol": "GOOGL", "name": "Alphabet Inc."},
                    {"symbol": "AMZN", "name": "Amazon.com Inc."},
                    {"symbol": "TSLA", "name": "Tesla Inc."},
                    {"symbol": "META", "name": "Meta Platforms Inc."},
                    {"symbol": "NVDA", "name": "NVIDIA Corporation"},
                    {"symbol": "NFLX", "name": "Netflix Inc."}
                ],
                "Technology": [
                    {"symbol": "ADBE", "name": "Adobe Inc."},
                    {"symbol": "CRM", "name": "Salesforce Inc."},
                    {"symbol": "ORCL", "name": "Oracle Corporation"},
                    {"symbol": "IBM", "name": "IBM"},
                    {"symbol": "INTC", "name": "Intel Corporation"},
                    {"symbol": "AMD", "name": "Advanced Micro Devices"}
                ],
                "Financial": [
                    {"symbol": "JPM", "name": "JPMorgan Chase & Co."},
                    {"symbol": "BAC", "name": "Bank of America Corp."},
                    {"symbol": "WFC", "name": "Wells Fargo & Company"},
                    {"symbol": "GS", "name": "Goldman Sachs Group"},
                    {"symbol": "MS", "name": "Morgan Stanley"},
                    {"symbol": "C", "name": "Citigroup Inc."}
                ],
                "Healthcare": [
                    {"symbol": "JNJ", "name": "Johnson & Johnson"},
                    {"symbol": "UNH", "name": "UnitedHealth Group"},
                    {"symbol": "PFE", "name": "Pfizer Inc."},
                    {"symbol": "ABT", "name": "Abbott Laboratories"},
                    {"symbol": "MRK", "name": "Merck & Co. Inc."}
                ]
            },
            "Commodities": {
                "Precious Metals": [
                    {"symbol": "GC=F", "name": "Gold Futures"},
                    {"symbol": "SI=F", "name": "Silver Futures"},
                    {"symbol": "PL=F", "name": "Platinum Futures"},
                    {"symbol": "PA=F", "name": "Palladium Futures"}
                ],
                "Energy": [
                    {"symbol": "CL=F", "name": "Crude Oil WTI"},
                    {"symbol": "BZ=F", "name": "Brent Crude Oil"},
                    {"symbol": "NG=F", "name": "Natural Gas"},
                    {"symbol": "RB=F", "name": "Gasoline"}
                ],
                "Agricultural": [
                    {"symbol": "ZC=F", "name": "Corn Futures"},
                    {"symbol": "ZS=F", "name": "Soybean Futures"},
                    {"symbol": "ZW=F", "name": "Wheat Futures"},
                    {"symbol": "CC=F", "name": "Cocoa Futures"},
                    {"symbol": "KC=F", "name": "Coffee Futures"},
                    {"symbol": "SB=F", "name": "Sugar Futures"}
                ],
                "Industrial Metals": [
                    {"symbol": "HG=F", "name": "Copper Futures"},
                    {"symbol": "ALI=F", "name": "Aluminum Futures"}
                ]
            },
            "Cryptocurrencies": {
                "Major Coins": [
                    {"symbol": "BTC-USD", "name": "Bitcoin"},
                    {"symbol": "ETH-USD", "name": "Ethereum"},
                    {"symbol": "BNB-USD", "name": "Binance Coin"},
                    {"symbol": "XRP-USD", "name": "Ripple"},
                    {"symbol": "ADA-USD", "name": "Cardano"},
                    {"symbol": "SOL-USD", "name": "Solana"},
                    {"symbol": "DOT-USD", "name": "Polkadot"},
                    {"symbol": "DOGE-USD", "name": "Dogecoin"}
                ],
                "DeFi Tokens": [
                    {"symbol": "UNI-USD", "name": "Uniswap"},
                    {"symbol": "LINK-USD", "name": "Chainlink"},
                    {"symbol": "AAVE-USD", "name": "Aave"},
                    {"symbol": "COMP-USD", "name": "Compound"},
                    {"symbol": "MKR-USD", "name": "Maker"},
                    {"symbol": "SUSHI-USD", "name": "SushiSwap"}
                ]
            },
            "Forex": {
                "Major Pairs": [
                    {"symbol": "EURUSD=X", "name": "EUR/USD"},
                    {"symbol": "GBPUSD=X", "name": "GBP/USD"},
                    {"symbol": "USDJPY=X", "name": "USD/JPY"},
                    {"symbol": "USDCHF=X", "name": "USD/CHF"},
                    {"symbol": "AUDUSD=X", "name": "AUD/USD"},
                    {"symbol": "USDCAD=X", "name": "USD/CAD"},
                    {"symbol": "NZDUSD=X", "name": "NZD/USD"}
                ],
                "Cross Pairs": [
                    {"symbol": "EURGBP=X", "name": "EUR/GBP"},
                    {"symbol": "EURJPY=X", "name": "EUR/JPY"},
                    {"symbol": "GBPJPY=X", "name": "GBP/JPY"},
                    {"symbol": "EURCHF=X", "name": "EUR/CHF"},
                    {"symbol": "GBPCHF=X", "name": "GBP/CHF"},
                    {"symbol": "AUDJPY=X", "name": "AUD/JPY"}
                ],
                "Exotic Pairs": [
                    {"symbol": "USDMXN=X", "name": "USD/MXN"},
                    {"symbol": "USDZAR=X", "name": "USD/ZAR"},
                    {"symbol": "USDTRY=X", "name": "USD/TRY"},
                    {"symbol": "USDBRL=X", "name": "USD/BRL"}
                ]
            }
        }
        
        return jsonify({
            "instruments": instruments,
            "total_count": sum(len(cat_items) for main_cat in instruments.values() for cat_items in main_cat.values()),
            "timestamp": datetime.now().isoformat()
        })
        
    except Exception as e:
        logger.error(f"Error in get_financial_instruments: {str(e)}")
        return jsonify({
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }), 500

# Keep backward compatibility
@app.route('/api/stocks')
def get_major_stocks():
    """API endpoint to get list of major US stocks (backward compatibility)"""
    return get_financial_instruments()

@app.route('/api/signals')
def get_signals():
    """API endpoint to get trading signals"""
    try:
        symbol = request.args.get('symbol', 'AAPL').upper()
        timeframe = request.args.get('timeframe', '1d')
        
        # Fetch stock data
        data = fetch_stock_data(symbol, timeframe)
        
        # Generate signals from both strategies
        smc_signal = smart_money_concepts_strategy(data, timeframe)
        sma_signal = sma_crossover_strategy(data, timeframe)
        
        # Add risk management for signals with BUY/SELL actions
        if smc_signal['signal'] in ['BUY', 'SELL']:
            smc_signal['risk_management'] = calculate_stop_loss_take_profit(data, smc_signal['signal'])
            smc_signal['support_resistance'] = calculate_support_resistance(data)
        
        if sma_signal['signal'] in ['BUY', 'SELL']:
            sma_signal['risk_management'] = calculate_stop_loss_take_profit(data, sma_signal['signal'])
            sma_signal['support_resistance'] = calculate_support_resistance(data)
        
        return jsonify({
            "symbol": symbol,
            "timeframe": timeframe,
            "timestamp": datetime.now().isoformat(),
            "signals": [smc_signal, sma_signal],
            "data_points": len(data)
        })
        
    except Exception as e:
        logger.error(f"Error in get_signals: {str(e)}")
        return jsonify({
            "error": str(e),
            "symbol": request.args.get('symbol', 'AAPL'),
            "timeframe": request.args.get('timeframe', '1d'),
            "timestamp": datetime.now().isoformat()
        }), 500

@app.route('/api/multitimeframe')
def get_multitimeframe_signals():
    """API endpoint to get trading signals across multiple timeframes"""
    try:
        symbol = request.args.get('symbol', 'AAPL').upper()
        
        # Define timeframes for analysis - now including 15m
        timeframes = ['1d', '4h', '1h', '15m', '1wk']  # Enhanced timeframe coverage
        
        results = {}
        
        for tf in timeframes:
            try:
                # Fetch stock data for this timeframe
                data = fetch_stock_data(symbol, tf)
                
                # Generate signals from both strategies
                smc_signal = smart_money_concepts_strategy(data, tf)
                sma_signal = sma_crossover_strategy(data, tf)
                
                # Simplified signals for multi-timeframe view
                results[tf] = {
                    'smc': {
                        'signal': smc_signal['signal'],
                        'confidence': smc_signal['confidence'],
                        'trend': smc_signal.get('details', {}).get('trend', 'Unknown')
                    },
                    'sma': {
                        'signal': sma_signal['signal'],
                        'confidence': sma_signal['confidence'],
                        'trend': sma_signal.get('details', {}).get('trend', 'Unknown')
                    },
                    'data_points': len(data)
                }
                
            except Exception as tf_error:
                logger.error(f"Error fetching {tf} data for {symbol}: {str(tf_error)}")
                results[tf] = {
                    'error': str(tf_error),
                    'smc': {'signal': 'ERROR', 'confidence': 0.0},
                    'sma': {'signal': 'ERROR', 'confidence': 0.0}
                }
        
        # Calculate overall consensus
        consensus = calculate_timeframe_consensus(results)
        
        return jsonify({
            "symbol": symbol,
            "timestamp": datetime.now().isoformat(),
            "timeframes": results,
            "consensus": consensus
        })
        
    except Exception as e:
        logger.error(f"Error in multi-timeframe analysis: {str(e)}")
        return jsonify({
            "error": str(e),
            "symbol": request.args.get('symbol', 'AAPL'),
            "timestamp": datetime.now().isoformat()
        }), 500

def calculate_timeframe_consensus(results):
    """Calculate consensus across multiple timeframes"""
    try:
        buy_signals = 0
        sell_signals = 0
        hold_signals = 0
        total_confidence = 0
        valid_signals = 0
        
        for tf_data in results.values():
            if 'error' in tf_data:
                continue
                
            for strategy in ['smc', 'sma']:
                signal = tf_data[strategy]['signal']
                confidence = tf_data[strategy]['confidence']
                
                if signal == 'BUY':
                    buy_signals += 1
                elif signal == 'SELL':
                    sell_signals += 1
                elif signal == 'HOLD':
                    hold_signals += 1
                
                total_confidence += confidence
                valid_signals += 1
        
        if valid_signals == 0:
            return {
                'overall_signal': 'ERROR',
                'confidence': 0.0,
                'buy_percentage': 0,
                'sell_percentage': 0,
                'hold_percentage': 0
            }
        
        # Determine consensus
        total_signals = buy_signals + sell_signals + hold_signals
        buy_pct = (buy_signals / total_signals) * 100 if total_signals > 0 else 0
        sell_pct = (sell_signals / total_signals) * 100 if total_signals > 0 else 0
        hold_pct = (hold_signals / total_signals) * 100 if total_signals > 0 else 0
        
        # Overall signal based on majority
        if buy_signals > sell_signals and buy_signals > hold_signals:
            overall_signal = 'BUY'
        elif sell_signals > buy_signals and sell_signals > hold_signals:
            overall_signal = 'SELL'
        else:
            overall_signal = 'HOLD'
        
        avg_confidence = total_confidence / valid_signals if valid_signals > 0 else 0
        
        return {
            'overall_signal': overall_signal,
            'confidence': round(avg_confidence, 2),
            'buy_percentage': round(buy_pct, 1),
            'sell_percentage': round(sell_pct, 1),
            'hold_percentage': round(hold_pct, 1),
            'total_signals': valid_signals
        }
        
    except Exception as e:
        logger.error(f"Error calculating consensus: {str(e)}")
        return {
            'overall_signal': 'ERROR',
            'confidence': 0.0,
            'error': str(e)
        }

@app.route('/api/explain')
def explain_signal():
    """API endpoint to get AI explanation of trading signals"""
    try:
        strategy = request.args.get('strategy', '')
        signal = request.args.get('signal', '')
        symbol = request.args.get('symbol', 'AAPL')
        
        if not strategy or not signal:
            return jsonify({"error": "Missing strategy or signal parameter"}), 400
        
        prompt = f"""
        Explain the {strategy} trading strategy and why it generated a {signal} signal for {symbol}.
        
        Please provide:
        1. A brief explanation of the {strategy} strategy
        2. What market conditions led to the {signal} signal
        3. What this signal means for traders
        4. Key risks and considerations
        
        Keep the explanation concise but informative, suitable for both beginner and intermediate traders.
        """
        
        response = openai_client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {
                    "role": "system",
                    "content": "You are a professional trading analyst with expertise in technical analysis and quantitative trading strategies. Provide clear, educational explanations about trading signals."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            max_tokens=500,
            temperature=0.7
        )
        
        explanation = response.choices[0].message.content
        
        return jsonify({
            "strategy": strategy,
            "signal": signal,
            "symbol": symbol,
            "explanation": explanation,
            "timestamp": datetime.now().isoformat()
        })
        
    except Exception as e:
        logger.error(f"Error in explain_signal: {str(e)}")
        return jsonify({
            "error": f"Failed to generate explanation: {str(e)}",
            "strategy": request.args.get('strategy', ''),
            "signal": request.args.get('signal', ''),
            "timestamp": datetime.now().isoformat()
        }), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
