# FinWalk - Advanced Financial Analysis Platform

## Overview

FinWalk is a comprehensive Flask-based financial analysis platform that provides professional-grade trading signals across multiple asset classes including stocks, commodities, cryptocurrencies, and forex. The platform features advanced technical analysis using Smart Money Concepts and quantitative strategies, with multi-timeframe analysis capabilities and AI-powered explanations via OpenAI's GPT-4o model.

## System Architecture

### Backend Architecture
- **Framework**: Flask (Python web framework)
- **API Design**: RESTful endpoints for stock data analysis
- **Data Processing**: Pandas and NumPy for financial data manipulation
- **Stock Data Source**: Yahoo Finance API via yfinance library
- **AI Integration**: OpenAI GPT-4o for signal explanations

### Frontend Architecture
- **Technology**: HTML/CSS/JavaScript (vanilla)
- **UI Framework**: Bootstrap 5 with dark theme
- **Design Pattern**: Single-page application with AJAX calls
- **Responsive Design**: Mobile-first approach using Bootstrap grid system

## Key Components

### Core Services
1. **Multi-Asset Data Engine**: Comprehensive data fetching across:
   - US Stocks (Technology, Healthcare, Financial, etc.)
   - Commodities (Precious metals, Energy, Agricultural, Industrial metals)
   - Cryptocurrencies (Major coins, DeFi tokens)
   - Forex (Major pairs, Cross pairs, Exotic pairs)
2. **Multi-Timeframe Analysis**: Enhanced timeframe coverage including 15m, 1h, 4h, 1d, 1wk, 1mo
3. **SMC Strategy Engine**: Advanced Smart Money Concepts implementation
4. **SMA Crossover Engine**: Quantitative strategy with multiple moving averages
5. **Risk Management System**: Professional-grade ATR-based calculations
6. **Multi-Timeframe Consensus Engine**: Intelligent signal aggregation across timeframes
7. **AI Explanation Generator**: GPT-4o powered contextual analysis

### API Endpoints
- `/api/signals` - Single timeframe trading signal generation
- `/api/multitimeframe` - Multi-timeframe consensus analysis (now includes 15m)
- `/api/instruments` - Comprehensive financial instruments catalog
- `/api/stocks` - Legacy endpoint (backward compatibility)
- `/api/explain` - AI-powered signal explanations

### User Interface Components
- **Timeframe Selector**: Dropdown for selecting analysis timeframe (1m to 1mo)
- **Stock Browser Modal**: Categorized listings of 69 major US stocks
- **Multi-Timeframe Modal**: Consensus analysis across multiple timeframes
- **Signal Cards**: Display trading signals with confidence indicators and detailed technical analysis
- **Risk Management Panels**: Stop loss/take profit levels with risk-reward ratios
- **Support/Resistance Display**: Daily pivot points and key technical levels
- **Detailed View Toggle**: Switch between simple and comprehensive analysis views
- **Confidence Bars**: Visual representation of signal strength
- **Explanation Panels**: Collapsible sections for AI-generated explanations
- **Loading States**: Spinner animations for async operations

## Data Flow

1. **User Input**: User enters stock symbol via web interface
2. **Data Fetching**: Backend retrieves historical data from Yahoo Finance
3. **Analysis**: SMC strategy processes data to identify trading opportunities
4. **Signal Generation**: Algorithm generates buy/sell signals with confidence scores
5. **AI Enhancement**: OpenAI API provides contextual explanations
6. **Response**: JSON response sent to frontend with signal data
7. **Display**: Frontend renders signals with visual indicators and explanations

## External Dependencies

### Core Dependencies
- **yfinance**: Yahoo Finance API for stock data
- **OpenAI**: GPT-4o integration for signal explanations
- **Flask-CORS**: Cross-origin resource sharing support
- **Pandas**: Data manipulation and analysis
- **NumPy**: Numerical computing

### Frontend Dependencies
- **Bootstrap 5**: UI framework with dark theme
- **Bootstrap Icons**: Icon library for visual elements

### Environment Variables
- `OPENAI_API_KEY`: OpenAI API authentication
- `SESSION_SECRET`: Flask session security (defaults to dev key)

## Deployment Strategy

### Development Environment
- Flask development server
- Environment variables for API keys
- Debug logging enabled

### Production Deployment
The application is configured for deployment on cloud platforms with the following files:
- `Procfile` - Gunicorn server configuration for Heroku/Railway/Render
- `runtime.txt` - Python version specification
- `app.json` - Platform-specific configuration metadata
- `DEPLOYMENT.md` - Comprehensive deployment guide

### Recommended Platforms
1. **Railway** - Free tier with $5 monthly credit, ideal for Flask apps
2. **Render** - Free tier available, automatic deployments
3. **Heroku** - Industry standard, paid plans starting $5/month

### Production Considerations
- WSGI server deployment (Gunicorn configured)
- Environment variable management (OPENAI_API_KEY required)
- CORS configuration for domain restrictions
- Rate limiting for API endpoints
- Error handling and monitoring

### Netlify Limitations
Netlify's free tier is designed for static sites and serverless functions, making it unsuitable for this Flask application which requires:
- Continuous server operation
- Real-time data processing
- Multiple API endpoints with complex calculations
- Background data fetching tasks

## Changelog

```
Changelog:
- July 02, 2025. Initial setup with Flask backend and basic trading strategies
- July 02, 2025. Enhanced with 69 major US stocks, advanced technical indicators
- July 02, 2025. Added comprehensive risk management and support/resistance levels
- July 02, 2025. Implemented multi-timeframe analysis with consensus engine
- July 02, 2025. Added stock browser modal and multi-timeframe dashboard
- July 02, 2025. **MAJOR UPDATE: Transformed to FinWalk platform**
  - Complete UI/UX redesign with modern gradient design and professional styling
  - Expanded to comprehensive multi-asset coverage: stocks, commodities, crypto, forex
  - Added 15m timeframe to multi-timeframe analysis
  - Created new FinWalk branding with custom logo and color scheme
  - Enhanced instrument browser with 100+ financial instruments across 4 asset classes
  - Improved mobile responsiveness and user experience
  - Professional-grade dashboard with advanced visualizations
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```

## Technical Notes

### Smart Money Concepts Implementation
The SMC strategy focuses on institutional trading patterns:
- **Break of Structure (BOS)**: Identifies when price breaks previous market structure
- **Change of Character (CHoCH)**: Detects shifts in market behavior
- **Market Structure Analysis**: Analyzes higher highs, lower lows, and trend changes

### AI Integration
- Uses OpenAI GPT-4o model (latest as of May 2024)
- Provides contextual explanations for trading signals
- Enhances user understanding of market analysis

### Data Processing
- Fetches 3 months of daily OHLCV data
- Real-time analysis capabilities
- Error handling for invalid stock symbols

## Security Considerations

- API key management through environment variables
- CORS configuration for cross-origin requests
- Input validation for stock symbols
- Session management for user interactions